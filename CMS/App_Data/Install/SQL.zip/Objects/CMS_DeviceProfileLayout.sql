SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_DeviceProfileLayout](
	[DeviceProfileLayoutID] [int] IDENTITY(1,1) NOT NULL,
	[DeviceProfileID] [int] NOT NULL,
	[SourceLayoutID] [int] NOT NULL,
	[TargetLayoutID] [int] NOT NULL,
	[DeviceProfileLayoutGUID] [uniqueidentifier] NOT NULL,
	[DeviceProfileLayoutLastModified] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_CMS_DeviceProfileLayout] PRIMARY KEY CLUSTERED 
(
	[DeviceProfileLayoutID] ASC
)
)

GO
CREATE NONCLUSTERED INDEX [IX_CMS_DeviceProfileLayout_DeviceProfileID] ON [dbo].[CMS_DeviceProfileLayout]
(
	[DeviceProfileID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_DeviceProfileLayout_SourceLayoutID] ON [dbo].[CMS_DeviceProfileLayout]
(
	[SourceLayoutID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_DeviceProfileLayout_TargetLayoutID] ON [dbo].[CMS_DeviceProfileLayout]
(
	[TargetLayoutID] ASC
)
GO
ALTER TABLE [dbo].[CMS_DeviceProfileLayout]  WITH CHECK ADD  CONSTRAINT [FK_CMS_DeviceProfileLayout_DeviceProfileID_CMS_DeviceProfile] FOREIGN KEY([DeviceProfileID])
REFERENCES [dbo].[CMS_DeviceProfile] ([ProfileID])
GO
ALTER TABLE [dbo].[CMS_DeviceProfileLayout] CHECK CONSTRAINT [FK_CMS_DeviceProfileLayout_DeviceProfileID_CMS_DeviceProfile]
GO
ALTER TABLE [dbo].[CMS_DeviceProfileLayout]  WITH CHECK ADD  CONSTRAINT [FK_CMS_DeviceProfileLayout_SourceLayoutID_CMS_Layout] FOREIGN KEY([SourceLayoutID])
REFERENCES [dbo].[CMS_Layout] ([LayoutID])
GO
ALTER TABLE [dbo].[CMS_DeviceProfileLayout] CHECK CONSTRAINT [FK_CMS_DeviceProfileLayout_SourceLayoutID_CMS_Layout]
GO
ALTER TABLE [dbo].[CMS_DeviceProfileLayout]  WITH CHECK ADD  CONSTRAINT [FK_CMS_DeviceProfileLayout_TargetLayoutID_CMS_Layout] FOREIGN KEY([TargetLayoutID])
REFERENCES [dbo].[CMS_Layout] ([LayoutID])
GO
ALTER TABLE [dbo].[CMS_DeviceProfileLayout] CHECK CONSTRAINT [FK_CMS_DeviceProfileLayout_TargetLayoutID_CMS_Layout]
GO
