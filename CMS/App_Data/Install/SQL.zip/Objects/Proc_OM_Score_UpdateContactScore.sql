SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Proc_OM_Score_UpdateContactScore]
  @RuleID int,
  @WhereCond nvarchar(max),
  @ContactIDs Type_CMS_OrderedIntegerTable READONLY,
  @RuleExpiration datetime2(7),
  @RuleValidUnits int,
  @RuleValidFor int
AS
BEGIN
  SET NOCOUNT ON;
  
  DECLARE @ruleType int;
  DECLARE @ruleScoreID int;
  DECLARE @ruleValue int;
  DECLARE @ruleParameter nvarchar(250);
  DECLARE @ruleIsRecurring bit;
  DECLARE @ruleMaxPoints int;
  DECLARE @expirationDate nvarchar(300);
  DECLARE @timeRestriction nvarchar(300);

  -- Get rule info
  SELECT
    @ruleType = [RuleType], 
    @ruleScoreID = [RuleScoreID], 
    @ruleValue = [RuleValue], 
    @ruleParameter = [RuleParameter], 
    @ruleIsRecurring = (CASE WHEN [RuleIsRecurring] = 0 OR [RuleIsRecurring] IS NULL THEN 0 ELSE 1 END),
    @ruleMaxPoints = [RuleMaxPoints] 
  FROM OM_Rule 
  WHERE RuleID=@RuleID

  IF ((SELECT COUNT([Value]) FROM @ContactIDs) = 0)
  BEGIN
    -- Retrieve all contacts for specified condition
    SET @WhereCond = '(' + @WhereCond + ') ' +
                     'AND ContactID NOT IN (SELECT ContactID FROM OM_ScoreContactRule WITH (UPDLOCK, HOLDLOCK) WHERE ScoreID = ' + CAST(@ruleScoreID as varchar(15)) + ' AND RuleID = ' + CAST(@RuleID as varchar(15)) + ')';
  END
  ELSE
  BEGIN
    -- Try to retrieve given contact for specified condition
    SET @WhereCond = 'ContactID IN (SELECT [Value] FROM @ContactIDs) AND (' + @WhereCond + ') ' + 
                     'AND ContactID NOT IN (SELECT ContactID FROM OM_ScoreContactRule WITH (UPDLOCK, HOLDLOCK) WHERE ScoreID = ' + CAST(@ruleScoreID as varchar(15)) + ' AND RuleID = ' + CAST(@RuleID as varchar(15)) + ' AND ContactID IN (SELECT [Value] FROM @ContactIDs))';
  END
  
  ------------------------------------------ Activity rule
  IF @ruleType = 0
  BEGIN 
    -- Prepare expiration date query
    SET @expirationDate =
    CASE @RuleValidUnits
      WHEN 0 THEN 'DATEADD(dd, ' + CAST(@RuleValidFor as varchar(50)) + ', MAX(ActivityCreated)) AS ActCreated'
      WHEN 1 THEN 'DATEADD(wk, ' + CAST(@RuleValidFor as varchar(50)) + ', MAX(ActivityCreated)) AS ActCreated'
      WHEN 2 THEN 'DATEADD(mm, ' + CAST(@RuleValidFor as varchar(50)) + ', MAX(ActivityCreated)) AS ActCreated'
      WHEN 3 THEN 'DATEADD(yy, ' + CAST(@RuleValidFor as varchar(50)) + ', MAX(ActivityCreated)) AS ActCreated'
      ELSE ISNULL('''' + CAST(@RuleExpiration as varchar(250)) + '''', 'NULL') + ' AS ActCreated'
    END
   
    -- Prepare time restriction in the past for time interval activities
    SET @timeRestriction =
    CASE @RuleValidUnits
      WHEN 0 THEN 'ActivityCreated >= DATEADD(dd, -' + CAST(@RuleValidFor as varchar(50)) + ', GETDATE())'
      WHEN 1 THEN 'ActivityCreated >= DATEADD(wk, -' + CAST(@RuleValidFor as varchar(50)) + ', GETDATE())'
      WHEN 2 THEN 'ActivityCreated >= DATEADD(mm, -' + CAST(@RuleValidFor as varchar(50)) + ', GETDATE())'
      WHEN 3 THEN 'ActivityCreated >= DATEADD(yy, -' + CAST(@RuleValidFor as varchar(50)) + ', GETDATE())'
      ELSE '1 = 1'
    END
             
    DECLARE @RuleValueExpression NVARCHAR(MAX);
    IF @ruleIsRecurring = 0
    BEGIN    
      SET @RuleValueExpression = @ruleValue
    END
    ELSE IF (@ruleMaxPoints IS NOT NULL) AND (@ruleMaxPoints <> 0)
    BEGIN
      IF @ruleMaxPoints > 0
        SET @RuleValueExpression = 'CASE WHEN ' + CAST(@ruleMaxPoints as varchar(50)) + ' < COUNT(ContactID) * ' + CAST(@ruleValue as varchar(50)) + ' THEN ' + CAST(@ruleMaxPoints as varchar(50)) + ' ELSE COUNT(ContactID) * ' + CAST(@ruleValue as varchar(50)) + ' END'
      ELSE
        SET @RuleValueExpression = 'CASE WHEN ' + CAST(@ruleMaxPoints as varchar(50)) + ' > COUNT(ContactID) * ' + CAST(@ruleValue as varchar(50)) + ' THEN ' + CAST(@ruleMaxPoints as varchar(50)) + ' ELSE COUNT(ContactID) * ' + CAST(@ruleValue as varchar(50)) + ' END'
    END
    ELSE
    BEGIN
      SET @RuleValueExpression = 'COUNT(ContactID) * ' + CAST(@ruleValue as varchar(50))
    END

    DECLARE @Query NVARCHAR(MAX) = 'INSERT INTO OM_ScoreContactRule 
                                    SELECT ' + CAST(@ruleScoreID AS NVARCHAR(15)) + ', ContactID, ' + CAST(@RuleID AS NVARCHAR(15)) + ', ' + @RuleValueExpression + ', ' + @expirationDate + '
                                    FROM OM_Activity 
                                    INNER JOIN OM_Contact ON OM_Contact.ContactID = OM_Activity.ActivityContactID 
                                    WHERE (' + @WhereCond + ') AND ' + @timeRestriction + '
                                    GROUP BY ContactID'
    
    EXEC sp_executesql @Query, N'@ContactIDs Type_CMS_OrderedIntegerTable READONLY', @ContactIDs

  ------------------------------------------ Attribute rule:
  END 
  ELSE IF @ruleType=1
  BEGIN
	DECLARE @InsertQuery NVARCHAR(MAX) = 'INSERT INTO OM_ScoreContactRule 
										  SELECT ' + CAST(@ruleScoreID AS NVARCHAR(15)) + ', ContactID, ' + CAST(@RuleID AS NVARCHAR(15)) + ', ' + CAST(@ruleValue AS NVARCHAR(15)) + ', NULL 
										  FROM OM_Contact
										  WHERE ' + @WhereCond

	EXEC sp_executesql @InsertQuery, N'@ContactIDs Type_CMS_OrderedIntegerTable READONLY', @ContactIDs
  END
END

GO
