SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Analytics_CampaignAssetUrl](
	[CampaignAssetUrlID] [int] IDENTITY(1,1) NOT NULL,
	[CampaignAssetUrlGuid] [uniqueidentifier] NOT NULL,
	[CampaignAssetUrlTarget] [nvarchar](max) NOT NULL,
	[CampaignAssetUrlPageTitle] [nvarchar](200) NOT NULL,
	[CampaignAssetUrlCampaignAssetID] [int] NOT NULL,
 CONSTRAINT [PK_Analytics_CampaignAssetUrl] PRIMARY KEY CLUSTERED 
(
	[CampaignAssetUrlID] ASC
)
)

GO
CREATE NONCLUSTERED INDEX [IX_Analytics_CampaignAssetUrl_CampaignAssetUrlCampaignAssetID] ON [dbo].[Analytics_CampaignAssetUrl]
(
	[CampaignAssetUrlCampaignAssetID] ASC
)
GO
ALTER TABLE [dbo].[Analytics_CampaignAssetUrl] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignAssetUrl_CampaignAssetUrlGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [CampaignAssetUrlGuid]
GO
ALTER TABLE [dbo].[Analytics_CampaignAssetUrl] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignAssetUrl_CampaignAssetUrlTarget]  DEFAULT (N'') FOR [CampaignAssetUrlTarget]
GO
ALTER TABLE [dbo].[Analytics_CampaignAssetUrl] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignAssetUrl_CampaignAssetUrlPageTitle]  DEFAULT (N'') FOR [CampaignAssetUrlPageTitle]
GO
ALTER TABLE [dbo].[Analytics_CampaignAssetUrl] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignAssetUrl_CampaignAssetUrlCampaignAssetID]  DEFAULT ((0)) FOR [CampaignAssetUrlCampaignAssetID]
GO
ALTER TABLE [dbo].[Analytics_CampaignAssetUrl]  WITH CHECK ADD  CONSTRAINT [FK_Analytics_CampaignAssetUrl_CampaignAssetUrlCampaignAssetID_Analytics_CampaignAsset] FOREIGN KEY([CampaignAssetUrlCampaignAssetID])
REFERENCES [dbo].[Analytics_CampaignAsset] ([CampaignAssetID])
GO
ALTER TABLE [dbo].[Analytics_CampaignAssetUrl] CHECK CONSTRAINT [FK_Analytics_CampaignAssetUrl_CampaignAssetUrlCampaignAssetID_Analytics_CampaignAsset]
GO
